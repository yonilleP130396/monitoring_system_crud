package ISF.Monitoring_System.Dashboard;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;


@Controller 
@RequestMapping("/dashboard")
public class DashboardController {

    @GetMapping
    public String getList() {
        return "dashboard/dashboard";
    }
    

}
