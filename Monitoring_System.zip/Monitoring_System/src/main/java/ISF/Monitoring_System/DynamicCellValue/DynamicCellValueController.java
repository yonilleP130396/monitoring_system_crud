package ISF.Monitoring_System.DynamicCellValue;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/dynamicCellValue")
@AllArgsConstructor
public class DynamicCellValueController {

    private final DynamicCellValueService cellService;

    // =========================
    // READ ALL
    // GET /dynamicCellValue
    // =========================
    @GetMapping
    public String getAll(Model model) {
        model.addAttribute("cellValues",cellService.findAll());
        return "dynamicCellValue/index";
    }

    // =========================
    // READ ONE
    // GET /dynamicCellValue/{id}
    // =========================
    @GetMapping("/{id}")
    public String getById(@PathVariable Long id,Model model) {

        return "dynamicCellValue/view";
    }

    // =========================
    // CREATE FORM
    // GET /dynamicCellValue/create
    // =========================
    @GetMapping("/create")
    public String createForm(Model model) {

        model.addAttribute("cellValue",new DynamicCellValueEntity());

        return "dynamicCellValue/create";
    }

    // =========================
    // CREATE
    // POST /dynamicCellValue
    // =========================
    @PostMapping
    public String create(@ModelAttribute DynamicCellValueEntity cellValue) {

        cellService.create(cellValue);

        return "redirect:/dynamicCellValue";
    }

    // =========================
    // UPDATE FORM
    // GET /dynamicCellValue/{id}/edit
    // =========================
    @GetMapping("/{id}/edit")
    public String editForm( @PathVariable Long id, Model model) {

        return "dynamicCellValue/edit";
    }

    // =========================
    // UPDATE
    // POST /dynamicCellValue/{id}
    // =========================
    @PostMapping("/{id}")
    public String update(@PathVariable Long id,@ModelAttribute DynamicCellValueEntity cellValue) {

        cellService.update(id, cellValue);

        return "redirect:/dynamicCellValue";
    }

    // =========================
    // DELETE
    // POST /dynamicCellValue/{id}/delete
    // =========================
    @PostMapping("/{id}/delete")
    public String delete(
            @PathVariable Long id) {

        cellService.delete(id);

        return "redirect:/dynamicCellValue";
    }
}
