package ISF.Monitoring_System.DynamicCellValue;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class DynamicCellValueService {

    private final DynamicCellValueRepository cellRepo;

    public List<DynamicCellValueEntity> findAll() {
        return cellRepo.findAll();
    }

    public Optional<DynamicCellValueEntity> findById(Long id) {
        return cellRepo.findById(id);
    }

  public DynamicCellValueEntity create(DynamicCellValueEntity cellValue) {
        DynamicCellValueEntity existing = new DynamicCellValueEntity();
        existing.setRowId(cellValue.getRowId());
        existing.setColumnId(cellValue.getColumnId());
        existing.setValue(cellValue.getValue());

        return cellRepo.save(existing);
    }

    public DynamicCellValueEntity update(Long id, DynamicCellValueEntity cellValue) {
        DynamicCellValueEntity existing = cellRepo.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "DynamicCellValueEntity not found with id: " + id
                ));

        existing.setRowId(cellValue.getRowId());
        existing.setColumnId(cellValue.getColumnId());
        existing.setValue(cellValue.getValue());

        return cellRepo.save(existing);
    }

    public void delete(Long id) {
        if (!cellRepo.existsById(id)) {
            throw new RuntimeException(
                    "DynamicCellValue not found with id: " + id
            );
        }

        cellRepo.deleteById(id);
    }
}

