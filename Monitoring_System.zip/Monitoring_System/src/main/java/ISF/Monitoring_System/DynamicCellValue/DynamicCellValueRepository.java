package ISF.Monitoring_System.DynamicCellValue;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DynamicCellValueRepository extends JpaRepository<DynamicCellValueEntity, Long>{

}
