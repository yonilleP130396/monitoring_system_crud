package ISF.Monitoring_System.DynamicCellValue;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "dynamic_cell_values")
@Data
public class DynamicCellValueEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "row_id", nullable = false)
    private Long rowId;

    @Column(name = "column_id", nullable = false)
    private Long columnId;

    @Column(name = "value")
    private String value;
}