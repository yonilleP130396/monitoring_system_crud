package ISF.Monitoring_System.DynamicColumn;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DynamicColumnRepository extends JpaRepository<DynamicColumnEntity, Long> {
    List<DynamicColumnEntity> findByTableIdOrderByColumnPosition(Long tableId); 

}
