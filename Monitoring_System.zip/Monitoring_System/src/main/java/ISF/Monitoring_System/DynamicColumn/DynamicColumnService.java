package ISF.Monitoring_System.DynamicColumn;

import java.util.List;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;

@Service 
@AllArgsConstructor 
public class DynamicColumnService {
    
    private final DynamicColumnRepository columnRepository;

    public List<DynamicColumnEntity> findAll() {
        return columnRepository.findAll();
    }

    public DynamicColumnEntity create(DynamicColumnEntity updatedColumn) {
        DynamicColumnEntity existingColumn = new DynamicColumnEntity();
        existingColumn.setTableId(updatedColumn.getTableId());
        existingColumn.setColumnName(updatedColumn.getColumnName());
        existingColumn.setColumnPosition(updatedColumn.getColumnPosition());
        
        return columnRepository.save(existingColumn);
    }

    public DynamicColumnEntity update(DynamicColumnEntity updatedColumn) {
        DynamicColumnEntity existingColumn = columnRepository.findById(updatedColumn.getId())
                .orElseThrow(() -> new RuntimeException("DynamicColumn not found with id: " + updatedColumn.getId()));
        existingColumn.setTableId(updatedColumn.getTableId());
        existingColumn.setColumnName(updatedColumn.getColumnName());
        existingColumn.setColumnPosition(updatedColumn.getColumnPosition());
        
        return columnRepository.save(existingColumn);
    }

     public DynamicColumnEntity findById(Long id) {
        return columnRepository.findById(id).orElseThrow(() -> new RuntimeException("DynamicTable not found with id: " + id));
    }

    public  List<DynamicColumnEntity> findByTableId(Long tableId){
        return  columnRepository.findByTableIdOrderByColumnPosition(tableId);
    }



    public void delete(Long id) {
        columnRepository.deleteById(id);
    }
}
