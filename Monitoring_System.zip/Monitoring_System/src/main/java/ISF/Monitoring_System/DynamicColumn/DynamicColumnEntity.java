package ISF.Monitoring_System.DynamicColumn;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "dynamic_columns")
@Data
public class DynamicColumnEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "table_id", nullable = false)
    private Long tableId;

    @Column(name = "column_name", nullable = false)
    private String columnName;

    @Column(name = "column_position", nullable = false)
    private Integer columnPosition;
}