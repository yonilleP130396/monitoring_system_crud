package ISF.Monitoring_System.DynamicColumn;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;



@Controller
@RequestMapping ("/dynamicColumn")
@AllArgsConstructor
public class DynamicColumnController {

    private final DynamicColumnService columnService;


    @GetMapping
    public String getAll(Model model) {
        model.addAttribute("columns",columnService.findAll());
        return "Monitoring_frontend/index";
    }

    @GetMapping("/{id}")
    public String getById(@PathVariable Long id,Model model) {

        return "dynamicColumn/view";
    }
    
    @GetMapping("/create")
    public String createForm(Model model) {

        model.addAttribute("column",new DynamicColumnEntity());

        return "dynamicColumn/create";
    }

    @PostMapping
    public String save(@ModelAttribute DynamicColumnEntity column) {

        columnService.create(column);

        return "redirect:/dynamicColumn";
    }

    @GetMapping("/{id}/edit")
    public String editForm( @PathVariable Long id, Model model) {

        return "dynamicColumn/edit";
    }

     

    @PostMapping("/{id}/delete")
    public String delete(
            @PathVariable Long id) {

        columnService.delete(id);

        return "redirect:/dynamicColumn";
    }
}
