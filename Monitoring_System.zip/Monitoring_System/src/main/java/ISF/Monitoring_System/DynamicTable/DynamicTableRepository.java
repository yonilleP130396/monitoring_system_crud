package ISF.Monitoring_System.DynamicTable;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DynamicTableRepository extends JpaRepository<DynamicTableEntity, Long> {

}