package ISF.Monitoring_System.DynamicTable;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import lombok.AllArgsConstructor;

import org.springframework.web.bind.annotation.*;

import ISF.Monitoring_System.DynamicColumn.DynamicColumnEntity;
import ISF.Monitoring_System.DynamicColumn.DynamicColumnService;
import ISF.Monitoring_System.DynamicRow.DynamicRowEntity;
import ISF.Monitoring_System.DynamicRow.DynamicRowService;

@Controller 
@RequestMapping("/dynamicTable")
@AllArgsConstructor
public class DynamicTableController {

    private final DynamicTableService dynamicTableService;
    private final DynamicColumnService dynamicColumnService;
    private final DynamicRowService dynamicRowService;
    /**
     * Display the list of all dynamic tables.
     */
    @GetMapping("/viewTable")
    public String showViewtable(Model model) {
        model.addAttribute("tables", dynamicTableService.findAll());
        return "dynamicTable/table-list";
    }

    /**
     * Show the form to create a new dynamic table.
     */
    @GetMapping("/addTable")
    public String showAddtable(Model model) {
        model.addAttribute("dynamicTable", new DynamicTableEntity());
        return "dynamicTable/dynamic-table";
    }

    /**
     * Handle submission of the new dynamic table form.
     */
    @PostMapping("/addTable")
    public String createTable(@ModelAttribute DynamicTableEntity dynamicTable) {
        dynamicTableService.create(dynamicTable);
        return "redirect:/dynamicTable/viewTable";
    }


    @PostMapping("/editTable")
    public String showEditTable(@RequestParam("id") Long id, Model model) {
        DynamicTableEntity dynamicTable = dynamicTableService.findById(id);
        List<DynamicColumnEntity> existingColumns = dynamicColumnService.findByTableId(id);

        if (existingColumns != null && !existingColumns.isEmpty()) {
            dynamicTable.setColumnsQuantity((long) existingColumns.size());
        }

        model.addAttribute("dynamicTable", dynamicTable);
        model.addAttribute("existingColumns", existingColumns); // Direct entity list
        
        return "dynamicTable/edit-table"; 
    }


    @PostMapping("/updateTable")
    public String updateTable(
            @ModelAttribute DynamicTableEntity dynamicTable,
            @RequestParam(value = "columnIds", required = false) List<Long> columnIds,
            @RequestParam(value = "columnNames", required = false) List<String> columnNames,
            @RequestParam(value = "columnPositions", required = false) List<Integer> columnPositions) {

        // 1. Update parent table metadata
        dynamicTableService.update(dynamicTable);

        // 2. Process create/update for columns
        if (columnNames != null && !columnNames.isEmpty()) {
            for (int i = 0; i < columnNames.size(); i++) {
                Long columnId = (columnIds != null && i < columnIds.size()) ? columnIds.get(i) : null;
                String name = columnNames.get(i);
                Integer position = (columnPositions != null && i < columnPositions.size()) ? columnPositions.get(i) : (i + 1);

                if (columnId != null) {
                    // UPDATE: Retrieve existing column and update its name & position
                    DynamicColumnEntity existingColumn = dynamicColumnService.findById(columnId);
                    if (existingColumn != null) {
                        existingColumn.setColumnName(name);
                        existingColumn.setColumnPosition(position);
                        dynamicColumnService.update(existingColumn);
                    }
                } else {
                    // CREATE: Instantiate and save new column
                    DynamicColumnEntity newColumn = new DynamicColumnEntity();
                    newColumn.setTableId(dynamicTable.getId());
                    newColumn.setColumnName(name);
                    newColumn.setColumnPosition(position);
                    dynamicColumnService.create(newColumn);
                }
            }
        }

        return "redirect:/dynamicTable/viewTable";
    }

    /**
     * Delete a dynamic table record by ID.
     */
    @GetMapping("/deleteTable/{id}")
    public String deleteTable(@PathVariable Long id) {
        dynamicTableService.delete(id);
        return "redirect:/dynamicTable/viewTable";
    }

    // @PostMapping("/view-table")
    // public String viewTable(@RequestParam ("id") Long id, Model model) {
    //     DynamicTableEntity dynamicTable = dynamicTableService.findById(id);
    //     List <DynamicColumnEntity> dynamicColumn = dynamicColumnService.findByTableId(id);
    //     List <DynamicRowEntity> dynamicRowEntities = dynamicRowService.findByTableId(id);
    //     model.addAttribute("dynamicColumn", dynamicColumn);
    //     model.addAttribute("dynamicTable", dynamicTable);
    //     model.addAttribute("dynamicRow", dynamicRowEntities);

    //     return "dynamicTable/view-table-name";
    // }

    @PostMapping("/view-table")
public String viewTable(@RequestParam("id") Long id, Model model) {
    DynamicTableEntity dynamicTable = dynamicTableService.findById(id);
    List<DynamicColumnEntity> dynamicColumns = dynamicColumnService.findByTableId(id);
    List<DynamicRowEntity> rawRows = dynamicRowService.findByTableId(id);

    // I-group ang cells ayon sa bilang ng columns (4 items per row group)
    int columnsCount = dynamicTable.getColumnsQuantity().intValue();
    List<List<DynamicRowEntity>> groupedRows = new ArrayList<>();
    
    for (int i = 0; i < rawRows.size(); i += columnsCount) {
        groupedRows.add(rawRows.subList(i, Math.min(i + columnsCount, rawRows.size())));
    }

    model.addAttribute("dynamicColumn", dynamicColumns);
    model.addAttribute("dynamicTable", dynamicTable);
    model.addAttribute("groupedRow", groupedRows); // I-pass ang naka-group na rows

    return "dynamicTable/view-table-name";
}
}