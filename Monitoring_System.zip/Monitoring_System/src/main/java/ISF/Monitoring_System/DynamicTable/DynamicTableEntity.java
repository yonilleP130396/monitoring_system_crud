package ISF.Monitoring_System.DynamicTable;

import org.hibernate.annotations.DynamicUpdate;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "dynamic_tables")
@Getter
@Setter
@DynamicUpdate 
public class DynamicTableEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "columns_quantity", nullable = false)
    private Long columnsQuantity;

}