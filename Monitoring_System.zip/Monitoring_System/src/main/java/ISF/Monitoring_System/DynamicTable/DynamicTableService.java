package ISF.Monitoring_System.DynamicTable;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@AllArgsConstructor
public class DynamicTableService {

    private final DynamicTableRepository tableRepo;

    /**
     * Retrieve all dynamic table records.
     */
    public List<DynamicTableEntity> findAll() {
        return tableRepo.findAll();
    }

    /**
     * Retrieve a single dynamic table record by its ID.
     */
    public DynamicTableEntity findById(Long id) {
        return tableRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("DynamicTable not found with id: " + id));
    }

    /**
     * Create a new dynamic table record.
     */
    @Transactional
    public DynamicTableEntity create(DynamicTableEntity source) {
        // Optional: Add pre-save validation or default value setting here
        DynamicTableEntity existingTable = new DynamicTableEntity();
         existingTable.setName(source.getName());
         existingTable.setColumnsQuantity(source.getColumnsQuantity());
        return tableRepo.save(existingTable);
    }

    /**
     * Update an existing dynamic table record.
     */
    @Transactional
    public DynamicTableEntity update(DynamicTableEntity source) {
        DynamicTableEntity existingTable = findById(source.getId());
         existingTable.setName(source.getName());
         existingTable.setColumnsQuantity(source.getColumnsQuantity());

        return tableRepo.save(existingTable);
    }

    /**
     * Delete a dynamic table record by its ID.
     */
    @Transactional
    public void delete(Long id) {
        DynamicTableEntity existingTable = findById(id);
        tableRepo.delete(existingTable);
    }
}