package ISF.Monitoring_System.DynamicRow;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface DynamicRowRepository extends JpaRepository<DynamicRowEntity, Long> {
    
    List<DynamicRowEntity> findByTableId(Long tableId);

}
