package ISF.Monitoring_System.DynamicRow;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "dynamic_rows")
@Data
public class DynamicRowEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "row_position", nullable = false)
    private Long rowPosition;

    @Column(name = "data_name", nullable = false)
    private String dataName;

    @Column(name = "table_id", nullable = false)
    private Long tableId;
}