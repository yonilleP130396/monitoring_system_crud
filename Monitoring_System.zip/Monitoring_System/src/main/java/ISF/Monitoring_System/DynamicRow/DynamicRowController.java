package ISF.Monitoring_System.DynamicRow;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
@RequestMapping ("/dynamicRow")
@AllArgsConstructor 
public class DynamicRowController {


    private final DynamicRowService rowService;

    @GetMapping
    public String getAll(Model model) {
        model.addAttribute("rows",rowService.findAll());
        return "dynamicRow/index";
    }

    @GetMapping("/{id}")
    public String getById(@PathVariable Long id,Model model) {

        return "dynamicRow/view";
    }

    @GetMapping("/create")
    public String createForm(Model model) {

        model.addAttribute("row",new DynamicRowEntity());

        return "dynamicRow/create";
    }

    @PostMapping
    public String save(@ModelAttribute DynamicRowEntity row) {

        rowService.create(row);

        return "redirect:/dynamicRow";
    }

    @GetMapping("/{id}/edit")
    public String editForm( @PathVariable Long id, Model model) {

        return "dynamicRow/edit";
    }

    @PostMapping("/{id}")
    public String update(@ModelAttribute DynamicRowEntity row) {

        rowService.update(row);

        return "redirect:/dynamicRow";
    }

    @PostMapping("/{id}/delete")
    public String delete(
            @PathVariable Long id) {

        rowService.delete(id);

        return "redirect:/dynamicRow";
    }
    
}
