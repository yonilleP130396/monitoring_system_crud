package ISF.Monitoring_System.DynamicRow;

import java.util.List;

import org.springframework.stereotype.Service;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor 
public class DynamicRowService {

    private final DynamicRowRepository rowRepository;

    public List<DynamicRowEntity> findAll() {
        return rowRepository.findAll();
    }

    public DynamicRowEntity create(DynamicRowEntity row) {
        return rowRepository.save(row);
    }

    public DynamicRowEntity update(DynamicRowEntity updatedRow) {
        DynamicRowEntity existingRow = rowRepository.findById(updatedRow.getId())
                .orElseThrow(() -> new RuntimeException("DynamicRow not found with id: " + updatedRow.getId()));

        existingRow.setTableId(updatedRow.getTableId());
        
        return rowRepository.save(existingRow);
    }

    public List<DynamicRowEntity> findByTableId (Long tableId) {
        return rowRepository.findByTableId(tableId);
    }

    public void delete(Long id) {
        rowRepository.deleteById(id);
    }


}
